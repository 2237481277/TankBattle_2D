﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 练习
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Bitmap im = new Bitmap(300, 300);
            Graphics m = Graphics.FromImage(im);
            Graphics g = m;

            DrawImage(im, 0, 0);
        }
    }
}
